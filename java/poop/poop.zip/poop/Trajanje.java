package poop;

public enum Trajanje {
	OSMINA(1),CETVRITNA(2);
	
	Trajanje(int v){val  =v;}
	private int val;
	public int getVal() {return val;}
	

}
