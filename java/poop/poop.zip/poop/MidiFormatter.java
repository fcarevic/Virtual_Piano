package poop;


public class MidiFormatter {

	public static native void  parsiraj(String imeIzlaznogFajla);
	
		// TODO Auto-generated method stub
		
	

}
