package poop;

public interface Formatter {
	public void format(Composition comp, String file_name);

}
